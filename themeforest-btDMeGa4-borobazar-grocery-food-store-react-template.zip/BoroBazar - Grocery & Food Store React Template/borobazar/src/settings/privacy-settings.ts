export const privacyPolicy = [
  {
    id: '1',
    title: 'privacy-one-title',
    description: 'privacy-one-content',
  },
  {
    id: '2',
    title: 'privacy-two-title',
    description: 'privacy-two-content',
  },
  {
    id: '3',
    title: 'privacy-three-title',
    description: 'privacy-three-content',
  },
  {
    id: '4',
    title: 'privacy-four-title',
    description: 'privacy-four-content',
  },
  {
    id: '5',
    title: 'privacy-five-title',
    description: 'privacy-five-content',
  },
  {
    id: '6',
    title: 'privacy-six-title',
    description: 'privacy-six-content',
  },
];
